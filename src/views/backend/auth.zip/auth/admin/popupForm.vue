<template>
  <!-- 对话框表单 -->
  <el-dialog
    class="ba-operate-dialog"
    :close-on-click-modal="false"
    :model-value="['Add', 'Edit'].includes(baTable.form.operate!)"
    @close="baTable.toggleForm"
    :destroy-on-close="true"
  >
    <template #header>
      <div
        class="title"
        v-drag="['.ba-operate-dialog', '.el-dialog__header']"
        v-zoom="'.ba-operate-dialog'"
      >
        {{ baTable.form.operate ? t(baTable.form.operate) : "" }}
      </div>
    </template>
    <el-scrollbar
      v-loading="baTable.form.loading"
      class="ba-table-form-scrollbar"
    >
      <div
        class="ba-operate-form"
        :class="'ba-' + baTable.form.operate + '-form'"
        :style="config.layout.shrink ? '' : 'width: calc(100% - ' + baTable.form.labelWidth! / 2 + 'px)'"
      >
        <el-form
          ref="formRef"
          @keyup.enter="baTable.onSubmit(formRef)"
          :model="baTable.form.items"
          :label-position="config.layout.shrink ? 'top' : 'right'"
          :label-width="baTable.form.labelWidth + 'px'"
          :rules="rules"
          v-if="!baTable.form.loading"
        >
          <div class="container">
            <div class="left">
              <!-- 已选结果展示 -->
              <div class="result-section" v-if="selectedUsers.length > 0">
                <h3>已选择人员 ({{ selectedUsers.length }})</h3>
                <el-table :data="selectedUsers" border>
                  <el-table-column prop="name" label="姓名" width="120" />
                  <el-table-column prop="workNo" label="工号" width="120" />
                  <el-table-column prop="position" label="职务" width="150" />
                  <el-table-column prop="orgName" label="所属部门" />
                  <el-table-column prop="phone" label="手机号" width="130" />
                </el-table>
              </div>
            </div>
            <div class="right">
              <el-button type="primary" @click="dialogVisible = true">
                选择联系人
              </el-button>
            </div>
          </div>
          <FormItem
            :label="t('auth.admin.username')"
            v-model="baTable.form.items!.username"
            type="string"
            prop="username"
            :placeholder="t('auth.admin.Administrator login')"
          />
          <FormItem
            :label="t('auth.admin.nickname')"
            v-model="baTable.form.items!.nickname"
            type="string"
            prop="nickname"
            :placeholder="
              t('Please input field', { field: t('auth.admin.nickname') })
            "
          />
          <FormItem
            :label="t('auth.admin.grouping')"
            v-model="baTable.form.items!.group_arr"
            prop="group_arr"
            type="remoteSelect"
            :key="'group-' + baTable.form.items!.id"
            :input-attr="{
                            multiple: true,
                            params: { isTree: true, absoluteAuth: adminInfo.id == baTable.form.items!.id ? 0 : 1 },
                            field: 'name',
                            remoteUrl: '/admin/auth.Group/index',
                            placeholder: t('Click select'),
                        }"
          />
          <FormItem
            :label="t('auth.admin.head portrait')"
            type="image"
            v-model="baTable.form.items!.avatar"
          />
          <FormItem
            :label="t('auth.admin.mailbox')"
            prop="email"
            v-model="baTable.form.items!.email"
            type="string"
            :placeholder="
              t('Please input field', { field: t('auth.admin.mailbox') })
            "
          />
          <FormItem
            :label="t('auth.admin.mobile')"
            prop="mobile"
            v-model="baTable.form.items!.mobile"
            type="string"
            :placeholder="
              t('Please input field', { field: t('auth.admin.mobile') })
            "
          />
          <FormItem
            :label="t('auth.admin.Password')"
            prop="password"
            v-model="baTable.form.items!.password"
            type="password"
            :placeholder="
              baTable.form.operate == 'Add'
                ? t('Please input field', { field: t('auth.admin.Password') })
                : t('auth.admin.Please leave blank if not modified')
            "
          />
          <el-form-item
            prop="motto"
            :label="t('auth.admin.Personal signature')"
          >
            <el-input
              @keyup.enter.stop=""
              @keyup.ctrl.enter="baTable.onSubmit(formRef)"
              v-model="baTable.form.items!.motto"
              type="textarea"
              :placeholder="
                t('Please input field', {
                  field: t('auth.admin.Personal signature'),
                })
              "
            ></el-input>
          </el-form-item>
          <FormItem
            :label="t('State')"
            v-model="baTable.form.items!.status"
            type="radio"
            :input-attr="{
              border: true,
              content: { '0': t('Disable'), '1': t('Enable') },
            }"
          />
        </el-form>
      </div>
    </el-scrollbar>
    <template #footer>
      <div
        :style="'width: calc(100% - ' + baTable.form.labelWidth! / 1.8 + 'px)'"
      >
        <el-button @click="baTable.toggleForm('')">{{ t("Cancel") }}</el-button>
        <el-button
          v-blur
          :loading="baTable.form.submitLoading"
          @click="baTable.onSubmit(formRef)"
          type="primary"
        >
          {{
            baTable.form.operateIds && baTable.form.operateIds.length > 1
              ? t("Save and edit next item")
              : t("Save")
          }}
        </el-button>
      </div>
    </template>
  </el-dialog>
  <!-- 弹窗模式 -->
  <el-dialog
    v-model="dialogVisible"
    title="选择联系人"
    width="1000px"
    :close-on-click-modal="false"
  >
    <ContactSelector
      :org-list="orgList"
      :user-list="userList"
      :multiple="true"
      :page-size="20"
      @confirm="handleConfirm"
      @cancel="handleCancel"
    />
  </el-dialog>
</template>

<script setup lang="ts">
import { ref, reactive, inject, watch } from "vue";
import { useI18n } from "vue-i18n";
import type baTableClass from "/@/utils/baTable";
import { regularPassword, buildValidatorData } from "/@/utils/validate";
import type { FormInstance, FormItemRule } from "element-plus";
import FormItem from "/@/components/formItem/index.vue";
import { useAdminInfo } from "/@/stores/adminInfo";
import { useConfig } from "/@/stores/config";
import ContactSelector from '/@/components/ContactSelector.vue'

const config = useConfig();
const adminInfo = useAdminInfo();
const formRef = ref<FormInstance>();
const baTable = inject("baTable") as baTableClass;

// 弹窗状态
const dialogVisible = ref(false)

// 组织列表
const orgList = ref([
    { id: '11111111-1111-1111-1111-111111111111', pid: null, name: '集团总部' },
    { id: '22222222-2222-2222-2222-222222222222', pid: '11111111-1111-1111-1111-111111111111', name: '技术部' },
    { id: '33333333-3333-3333-3333-333333333333', pid: '11111111-1111-1111-1111-111111111111', name: '市场部' },
    { id: '44444444-4444-4444-4444-444444444444', pid: '22222222-2222-2222-2222-222222222222', name: '研发中心' },
    { id: '55555555-5555-5555-5555-555555555555', pid: '22222222-2222-2222-2222-222222222222', name: '测试中心' },
    { id: '66666666-6666-6666-6666-666666666666', pid: '33333333-3333-3333-3333-333333333333', name: '品牌推广' },
    { id: '77777777-7777-7777-7777-777777777777', pid: '33333333-3333-3333-3333-333333333333', name: '销售团队' },
])

// 用户列表
const userList = ref([
    {
        id: 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
        name: '张三',
        workNo: 'EMP001',
        phone: '13800138000',
        position: '技术总监',
        orgId: '22222222-2222-2222-2222-222222222222'
    },
    {
        id: 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb',
        name: '李四',
        workNo: 'EMP002',
        phone: '13800138001',
        position: '高级工程师',
        orgId: '44444444-4444-4444-4444-444444444444'
    },
    {
        id: 'cccccccc-cccc-cccc-cccc-cccccccccccc',
        name: '王五',
        workNo: 'EMP003',
        phone: '13800138002',
        position: '测试工程师',
        orgId: '55555555-5555-5555-5555-555555555555'
    },
    {
        id: 'dddddddd-dddd-dddd-dddd-dddddddddddd',
        name: '赵六',
        workNo: 'EMP004',
        phone: '13800138003',
        position: '市场经理',
        orgId: '33333333-3333-3333-3333-333333333333'
    },
    {
        id: 'eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee',
        name: '孙七',
        workNo: 'EMP005',
        phone: '13800138004',
        position: '品牌专员',
        orgId: '66666666-6666-6666-6666-666666666666'
    },
    {
        id: 'ffffffff-ffff-ffff-ffff-ffffffffffff',
        name: '周八',
        workNo: 'EMP006',
        phone: '13800138005',
        position: '销售主管',
        orgId: '77777777-7777-7777-7777-777777777777'
    },
])

// 已选用户
const selectedUsers = ref([])

// 确认选择
const handleConfirm = (users) => {
    selectedUsers.value = users
    dialogVisible.value = false
    
    console.log('选择的用户:', users)
    
    // 这里可以调用父组件的方法或 API
    // emit('users-selected', users)
}

// 取消选择
const handleCancel = () => {
    dialogVisible.value = false
}


const { t } = useI18n();

const rules: Partial<Record<string, FormItemRule[]>> = reactive({
  username: [
    buildValidatorData({ name: "required", title: t("auth.admin.username") }),
    buildValidatorData({ name: "account" }),
  ],
  nickname: [
    buildValidatorData({ name: "required", title: t("auth.admin.nickname") }),
  ],
  group_arr: [
    buildValidatorData({
      name: "required",
      message: t("Please select field", { field: t("auth.admin.grouping") }),
    }),
  ],
  email: [
    buildValidatorData({
      name: "email",
      message: t("Please enter the correct field", {
        field: t("auth.admin.mailbox"),
      }),
    }),
  ],
  mobile: [
    buildValidatorData({
      name: "mobile",
      message: t("Please enter the correct field", {
        field: t("auth.admin.mobile"),
      }),
    }),
  ],
  password: [
    {
      validator: (rule: any, val: string, callback: Function) => {
        if (baTable.form.operate == "Add") {
          if (!val) {
            return callback(
              new Error(
                t("Please input field", { field: t("auth.admin.Password") })
              )
            );
          }
        } else {
          if (!val) {
            return callback();
          }
        }
        if (!regularPassword(val)) {
          return callback(
            new Error(t("validate.Please enter the correct password"))
          );
        }
        return callback();
      },
      trigger: "blur",
    },
  ],
});

watch(
  () => baTable.form.operate,
  (newVal) => {
    rules.password![0].required = newVal == "Add";
  }
);
</script>

<style scoped lang="scss">
.container {
  display: flex;
  justify-content: space-between; /* 或 flex-start / flex-end / center */
  align-items: center; /* 垂直方向居中 */
}
.avatar-uploader {
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  border-radius: var(--el-border-radius-small);
  box-shadow: var(--el-box-shadow-light);
  border: 1px dashed var(--el-border-color);
  cursor: pointer;
  overflow: hidden;
  width: 110px;
  height: 110px;
}
.avatar-uploader:hover {
  border-color: var(--el-color-primary);
}
.avatar {
  width: 110px;
  height: 110px;
  display: block;
}
.image-slot {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
}

.contact-page {
    padding: 40px;
}

.result-section {
    margin-top: 40px;
    
    h3 {
        font-size: 18px;
        font-weight: 600;
        color: #1d1d1f;
        margin-bottom: 16px;
    }
}

:deep(.el-dialog__body) {
    padding: 0;
}
</style>
